# Electro-Legion-Group-Extension
A group extension for Electro Legion that handles shouts.
